package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

class BotForegroundService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "paperbot.RESULT_CODE"
        const val EXTRA_RESULT_DATA = "paperbot.RESULT_DATA"
        private const val TAG = "PaperBotForeground"
        private const val NOTIFICATION_ID = 4107
        private const val CHANNEL_ID = "paperbot_capture_channel"
        private const val CAPTURE_MAX_LONG_SIDE = 1280
    }

    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var captureWidth = 0
    private var captureHeight = 0
    private var tempFrameRgba = ByteArray(0)

    private val visionEngine = VisionEngine()

    private var lastFrameAt = 0L
    private var frameCount = 0L
    private var lastFpsSampleTime = 0L
    private var fpsCounter = 0
    private var currentFps = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        workerThread = HandlerThread("PaperBotVisionWorker").apply { start() }
        workerHandler = Handler(workerThread!!.looper)
        BotCommandBus.attachForeground(this)
        BotCommandBus.setVisionMode(
            if (visionEngine.isOpenCvLoaded) "OpenCV 4.9.0 Engine" else "Native Ultra-Fast Matrix Engine"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        @Suppress("DEPRECATION")
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode == -1 || resultData == null) {
            BotCommandBus.addLog("MediaProjection consent invalid or missing.")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
            startCapture(resultCode, resultData)
            BotCommandBus.updateStatus("RUNNING")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to start foreground projection service", t)
            BotCommandBus.addLog("Service startup failed: ${t.message}")
            stopSelf()
        }

        return START_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val longSide = max(metrics.widthPixels, metrics.heightPixels)
        val scale = if (longSide > CAPTURE_MAX_LONG_SIDE) CAPTURE_MAX_LONG_SIDE.toDouble() / longSide else 1.0
        captureWidth = max(1, (metrics.widthPixels * scale).toInt())
        captureHeight = max(1, (metrics.heightPixels * scale).toInt())
        tempFrameRgba = ByteArray(captureWidth * captureHeight * 4)

        visionEngine.initDimensions(captureWidth, captureHeight)

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)

        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader ->
            val image = try {
                reader.acquireLatestImage()
            } catch (t: Throwable) {
                null
            } ?: return@setOnImageAvailableListener

            try {
                val now = SystemClock.elapsedRealtime()
                val targetIntervalMs = 1000L / BotCommandBus.settings.value.targetFps.coerceIn(15, 60)
                if (now - lastFrameAt < targetIntervalMs) return@setOnImageAvailableListener
                lastFrameAt = now

                val plane = image.planes[0]
                val buffer = plane.buffer
                val rowStride = plane.rowStride
                val tightRowBytes = captureWidth * 4
                val limit = buffer.limit()

                // Safe row copy respecting buffer bounds
                for (y in 0 until captureHeight) {
                    val pos = y * rowStride
                    if (pos + tightRowBytes <= limit) {
                        buffer.position(pos)
                        buffer.get(tempFrameRgba, y * tightRowBytes, tightRowBytes)
                    }
                }

                visionEngine.copyFrame(tempFrameRgba)
                val chosenAngle = visionEngine.step(BotCommandBus.settings.value)

                frameCount++
                fpsCounter++
                if (now - lastFpsSampleTime >= 1000L) {
                    currentFps = fpsCounter
                    fpsCounter = 0
                    lastFpsSampleTime = now
                }

                val head = visionEngine.playerHead
                val normHead = if (head != null) {
                    Pair((head.x / captureWidth).toFloat(), (head.y / captureHeight).toFloat())
                } else null

                if (chosenAngle != null && head != null) {
                    sendAdaptiveSwipe(head.x, head.y, chosenAngle, visionEngine.dangerDetected)
                }

                val statusDesc = when {
                    !visionEngine.isCalibrated -> "CALIBRATING HUE"
                    visionEngine.dangerDetected -> "EVADING DANGER"
                    BotCommandBus.isPaused.value -> "PAUSED"
                    else -> "HUNTING TERRITORY"
                }

                BotCommandBus.updateStatus(statusDesc)
                BotCommandBus.updateTelemetry(
                    curFps = currentFps,
                    totalFrames = frameCount,
                    playerPos = normHead,
                    angle = chosenAngle ?: visionEngine.lastDirection,
                    evasions = visionEngine.evasionsCount,
                    skills = visionEngine.skillsUsedCount
                )
            } catch (t: Throwable) {
                Log.e(TAG, "Frame processing exception", t)
            } finally {
                image.close()
            }
        }, workerHandler)

        virtualDisplay = projection!!.createVirtualDisplay(
            "PaperBotVirtualDisplay",
            captureWidth,
            captureHeight,
            resources.configuration.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            workerHandler
        )

        BotCommandBus.addLog("Screen virtual display started at ${captureWidth}x${captureHeight}")
    }

    private fun sendAdaptiveSwipe(headX: Double, headY: Double, angle: Double, danger: Boolean) {
        val angleDiff = abs(normalizeAngle(angle - visionEngine.lastDirection))
        if (!danger && angleDiff < 0.35) return

        val swipeDistancePx = 130.0
        val x0 = (headX / captureWidth).toFloat().coerceIn(0.02f, 0.98f)
        val y0 = (headY / captureHeight).toFloat().coerceIn(0.02f, 0.98f)
        val x1 = ((headX + cos(angle) * swipeDistancePx) / captureWidth).toFloat().coerceIn(0.02f, 0.98f)
        val y1 = ((headY + sin(angle) * swipeDistancePx) / captureHeight).toFloat().coerceIn(0.02f, 0.98f)

        BotCommandBus.requestSwipe(x0, y0, x1, y1, danger)
        visionEngine.lastDirection = angle
    }

    private fun normalizeAngle(a: Double): Double {
        var x = a % (2.0 * Math.PI)
        if (x > Math.PI) x -= 2.0 * Math.PI
        if (x < -Math.PI) x += 2.0 * Math.PI
        return x
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PaperBot Screen Analysis",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays running status of PaperBot game assistant"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PaperBot AI Active")
            .setContentText("Autonomous game assistant running with vision intelligence")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        try { imageReader?.close() } catch (_: Throwable) {}
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        visionEngine.release()
        workerThread?.quitSafely()
        BotCommandBus.detachForeground(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
