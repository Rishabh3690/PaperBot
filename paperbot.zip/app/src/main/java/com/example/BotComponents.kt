package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonDanger
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun StatusCard(
    isServiceRunning: Boolean,
    statusText: String,
    fps: Int,
    frameCount: Long,
    evasions: Int,
    skillsCount: Int,
    visionMode: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(
                                color = if (isServiceRunning) NeonGreen else NeonDanger,
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isServiceRunning) "BOT ACTIVE" else "BOT STANDBY",
                        color = if (isServiceRunning) NeonGreen else TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant
                ) {
                    Text(
                        text = statusText,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(label = "FPS", value = "$fps", color = NeonCyan)
                MetricItem(label = "Frames", value = "$frameCount", color = TextPrimary)
                MetricItem(label = "Evasions", value = "$evasions", color = NeonYellow)
                MetricItem(label = "Skills", value = "$skillsCount", color = NeonBlue)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Engine: $visionMode",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun MetricItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(text = label, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
fun PermissionCheckItem(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    buttonLabel: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isGranted) DarkBorder else NeonYellow.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = if (isGranted) "Granted" else "Pending",
                    tint = if (isGranted) NeonGreen else NeonYellow,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
                }
            }

            if (!isGranted) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonBlue),
                    modifier = Modifier.testTag("grant_button_${title.replace(" ", "_").lowercase()}")
                ) {
                    Text(text = buttonLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = NeonGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "ENABLED",
                        color = NeonGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BotRadarWidget(
    activeAngle: Double,
    playerPos: Pair<Float, Float>?,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("radar_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VISION RADAR & HEADING",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Angle: ${(activeAngle * 180.0 / Math.PI).toInt()}°",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF070B14)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val maxR = minOf(size.width, size.height) * 0.42f

                    // Concentric radar rings
                    drawCircle(color = DarkBorder, radius = maxR * 0.33f, center = center, style = Stroke(width = 1.dp.toPx()))
                    drawCircle(color = DarkBorder, radius = maxR * 0.66f, center = center, style = Stroke(width = 1.dp.toPx()))
                    drawCircle(color = DarkBorder, radius = maxR, center = center, style = Stroke(width = 1.5.dp.toPx()))

                    // Crosshairs
                    drawLine(
                        color = DarkBorder,
                        start = Offset(center.x - maxR, center.y),
                        end = Offset(center.x + maxR, center.y),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = DarkBorder,
                        start = Offset(center.x, center.y - maxR),
                        end = Offset(center.x, center.y + maxR),
                        strokeWidth = 1.dp.toPx()
                    )

                    // 16 directional scanning rays
                    for (i in 0 until 16) {
                        val angle = i * (2.0 * Math.PI / 16.0)
                        val endX = center.x + (cos(angle) * maxR).toFloat()
                        val endY = center.y + (sin(angle) * maxR).toFloat()
                        drawLine(
                            color = NeonCyan.copy(alpha = 0.12f),
                            start = center,
                            end = Offset(endX, endY),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // Active heading arrow
                    val arrowLength = maxR * 0.9f
                    val arrowEndX = center.x + (cos(activeAngle) * arrowLength).toFloat()
                    val arrowEndY = center.y + (sin(activeAngle) * arrowLength).toFloat()

                    drawLine(
                        color = NeonGreen,
                        start = center,
                        end = Offset(arrowEndX, arrowEndY),
                        strokeWidth = 3.dp.toPx()
                    )

                    drawCircle(
                        color = NeonGreen,
                        radius = 6.dp.toPx(),
                        center = Offset(arrowEndX, arrowEndY)
                    )

                    // Player center indicator
                    val playerDotCenter = if (playerPos != null) {
                        Offset(
                            center.x + (playerPos.first - 0.5f) * maxR * 1.4f,
                            center.y + (playerPos.second - 0.5f) * maxR * 1.4f
                        )
                    } else center

                    drawCircle(
                        color = NeonCyan,
                        radius = 8.dp.toPx(),
                        center = playerDotCenter
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = playerDotCenter
                    )
                }

                if (playerPos == null) {
                    Text(
                        text = "Searching for Player Head...",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun GestureSimulatorSandbox(
    onTestSwipe: (Float, Float, Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val swipePoints = remember { mutableStateListOf<Offset>() }
    var lastSwipeDesc by remember { mutableStateOf("Drag on canvas or tap test button") }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("simulator_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GESTURE SIMULATOR & TEST",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )

                Button(
                    onClick = {
                        // Test simulated right swipe
                        onTestSwipe(0.3f, 0.5f, 0.7f, 0.5f)
                        lastSwipeDesc = "Dispatched test swipe right (0.3 -> 0.7)"
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.testTag("test_swipe_button")
                ) {
                    Text("Trigger Test Swipe", color = NeonCyan, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF070B14))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                swipePoints.clear()
                                swipePoints.add(offset)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                swipePoints.add(change.position)
                            },
                            onDragEnd = {
                                if (swipePoints.size > 1) {
                                    val start = swipePoints.first()
                                    val end = swipePoints.last()
                                    val x0 = start.x / size.width
                                    val y0 = start.y / size.height
                                    val x1 = end.x / size.width
                                    val y1 = end.y / size.height
                                    onTestSwipe(x0, y0, x1, y1)
                                    lastSwipeDesc = "Swiped (${x0.format(2)}, ${y0.format(2)}) -> (${x1.format(2)}, ${y1.format(2)})"
                                }
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (swipePoints.size > 1) {
                        val path = Path().apply {
                            moveTo(swipePoints[0].x, swipePoints[0].y)
                            for (i in 1 until swipePoints.size) {
                                lineTo(swipePoints[i].x, swipePoints[i].y)
                            }
                        }
                        drawPath(
                            path = path,
                            color = NeonCyan,
                            style = Stroke(width = 4.dp.toPx())
                        )
                        drawCircle(
                            color = NeonYellow,
                            radius = 6.dp.toPx(),
                            center = swipePoints.last()
                        )
                    }
                }

                Text(
                    text = lastSwipeDesc,
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                )
            }
        }
    }
}

private fun Float.format(digits: Int) = "%.${digits}f".format(this)
