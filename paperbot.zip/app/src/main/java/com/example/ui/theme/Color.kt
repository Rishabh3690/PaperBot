package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonBlue = Color(0xFF2B7FFF)
val NeonCyan = Color(0xFF00F0FF)
val NeonGreen = Color(0xFF10B981)
val NeonYellow = Color(0xFFFFB703)
val NeonDanger = Color(0xFFFF3366)

val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1C2640)
val DarkBorder = Color(0xFF2E3E66)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CyberPurple = Color(0xFF8B5CF6)
val CyberPink = Color(0xFFEC4899)
