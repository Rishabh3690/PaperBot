package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

class BotAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "PaperBotTouch"
        private const val SWIPE_DURATION_MS = 65L
        private const val TAP_DURATION_MS = 45L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var gestureInFlight = false
    @Volatile private var lastSwipeAtMs = 0L
    @Volatile private var lastTapAtMs = 0L
    private var screenWidth = 1080
    private var screenHeight = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        updateDimensions()
        BotCommandBus.attachAccessibility(this)
        Log.i(TAG, "Touch bridge connected: ${screenWidth}x${screenHeight}")
    }

    private fun updateDimensions() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                screenWidth = bounds.width().coerceAtLeast(1)
                screenHeight = bounds.height().coerceAtLeast(1)
            } else {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(metrics)
                screenWidth = metrics.widthPixels.coerceAtLeast(1)
                screenHeight = metrics.heightPixels.coerceAtLeast(1)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error calculating dimensions", e)
        }
    }

    fun requestSwipe(
        x0Norm: Float,
        y0Norm: Float,
        x1Norm: Float,
        y1Norm: Float,
        danger: Boolean,
        gapMs: Long
    ): Boolean {
        mainHandler.post {
            val now = SystemClock.elapsedRealtime()
            if (gestureInFlight) return@post
            if (now - lastSwipeAtMs < gapMs) return@post

            val x0 = (x0Norm.coerceIn(0.01f, 0.99f) * (screenWidth - 1))
            val y0 = (y0Norm.coerceIn(0.01f, 0.99f) * (screenHeight - 1))
            val x1 = (x1Norm.coerceIn(0.01f, 0.99f) * (screenWidth - 1))
            val y1 = (y1Norm.coerceIn(0.01f, 0.99f) * (screenHeight - 1))

            val path = Path().apply {
                moveTo(x0, y0)
                lineTo(x1, y1)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, SWIPE_DURATION_MS))
                .build()

            gestureInFlight = true
            lastSwipeAtMs = now
            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureInFlight = false
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureInFlight = false
                }
            }, mainHandler)

            if (!dispatched) {
                gestureInFlight = false
            }
        }
        return true
    }

    fun requestTap(xNorm: Float, yNorm: Float, onDispatched: () -> Unit): Boolean {
        mainHandler.post {
            val now = SystemClock.elapsedRealtime()
            if (gestureInFlight) return@post
            if (now - lastTapAtMs < 60L) return@post

            val x = (xNorm.coerceIn(0.01f, 0.99f) * (screenWidth - 1))
            val y = (yNorm.coerceIn(0.01f, 0.99f) * (screenHeight - 1))

            // Non-zero path length ensures compatibility across all Android versions
            val path = Path().apply {
                moveTo(x, y)
                lineTo(x + 1f, y + 1f)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
                .build()

            gestureInFlight = true
            lastTapAtMs = now
            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureInFlight = false
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureInFlight = false
                }
            }, mainHandler)

            if (dispatched) {
                onDispatched()
            } else {
                gestureInFlight = false
            }
        }
        return true
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

    override fun onInterrupt() {
        gestureInFlight = false
    }

    override fun onDestroy() {
        BotCommandBus.detachAccessibility(this)
        super.onDestroy()
    }
}
