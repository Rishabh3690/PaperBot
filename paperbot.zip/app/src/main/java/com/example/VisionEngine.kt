package com.example

import android.graphics.Color
import android.util.Log
import org.opencv.android.OpenCVLoader
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class VisionEngine {

    companion object {
        private const val TAG = "PaperBotVisionEngine"

        private const val PLAYER_S_MIN = 90
        private const val PLAYER_V_MIN = 80
        private const val WALL_V_MAX = 50
        private const val ENEMY_S_MIN = 95
        private const val ENEMY_V_MIN = 80

        private const val RAY_COUNT = 32
        private const val RAY_SAMPLES = 25
        private const val WALL_PROXIMITY_PX = 14
        private const val CORRIDOR_CHECK_PX = 80

        private const val SKILL_COOLDOWN_MS = 2800L
        private const val SKILL_READY_BRIGHTNESS = 130
        private const val SKILL_READY_SATURATION = 90
        private const val DANGER_RADIUS_PX = 130
    }

    var isOpenCvLoaded: Boolean = false
        private set

    private var captureWidth = 0
    private var captureHeight = 0

    // OpenCV Mats (if available)
    private var rgbaMat: Mat? = null
    private var rgbMat: Mat? = null
    private var hsvMat: Mat? = null
    private var playerMask: Mat? = null
    private var enemyMask: Mat? = null
    private var enemyThickMask: Mat? = null
    private var enemyTrailMask: Mat? = null
    private var morphKernel: Mat? = null

    // Native byte buffers for fast direct pixel lookups
    private var packedRgba = ByteArray(0)
    private var hsvBytes = ByteArray(0)

    var playerHead: Point? = null
        private set

    var lastDirection: Double = 0.0
    var dangerDetected: Boolean = false
        private set

    var playerHueMin: Int = 80
        private set
    var playerHueMax: Int = 140
        private set
    var isCalibrated: Boolean = false
        private set
    private var calibrationFrames = 0

    private val skillButtonXs = FloatArray(6)
    private val skillButtonYs = FloatArray(6)
    private val lastSkillUsedAt = LongArray(6) { 0L }
    private val skillButtonCount = 4

    var evasionsCount = 0
        private set
    var skillsUsedCount = 0
        private set

    init {
        try {
            isOpenCvLoaded = OpenCVLoader.initLocal()
            Log.i(TAG, "OpenCVLoader init: $isOpenCvLoaded")
        } catch (t: Throwable) {
            isOpenCvLoaded = false
            Log.w(TAG, "OpenCV native loading skipped, running optimized Kotlin pixel engine", t)
        }
    }

    fun initDimensions(width: Int, height: Int) {
        captureWidth = width
        captureHeight = height

        packedRgba = ByteArray(captureWidth * captureHeight * 4)
        hsvBytes = ByteArray(captureWidth * captureHeight * 3)

        if (isOpenCvLoaded) {
            try {
                rgbaMat = Mat(captureHeight, captureWidth, CvType.CV_8UC4)
                rgbMat = Mat(captureHeight, captureWidth, CvType.CV_8UC3)
                hsvMat = Mat(captureHeight, captureWidth, CvType.CV_8UC3)
                playerMask = Mat(captureHeight, captureWidth, CvType.CV_8UC1)
                enemyMask = Mat(captureHeight, captureWidth, CvType.CV_8UC1)
                enemyThickMask = Mat(captureHeight, captureWidth, CvType.CV_8UC1)
                enemyTrailMask = Mat(captureHeight, captureWidth, CvType.CV_8UC1)
                morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(9.0, 9.0))
            } catch (t: Throwable) {
                Log.w(TAG, "OpenCV mat allocation error, switching to native matrix engine", t)
                isOpenCvLoaded = false
            }
        }

        // Layout skill buttons at bottom
        val spacing = captureWidth / (skillButtonCount + 1)
        for (i in 0 until 6) {
            skillButtonXs[i] = spacing * (i + 1).toFloat()
            skillButtonYs[i] = captureHeight - (captureHeight / 12f)
        }
    }

    fun copyFrame(rgbaInput: ByteArray) {
        val totalBytes = min(packedRgba.size, rgbaInput.size)
        System.arraycopy(rgbaInput, 0, packedRgba, 0, totalBytes)

        if (isOpenCvLoaded && rgbaMat != null && rgbMat != null && hsvMat != null) {
            try {
                rgbaMat!!.put(0, 0, packedRgba)
                Imgproc.cvtColor(rgbaMat!!, rgbMat!!, Imgproc.COLOR_RGBA2RGB)
                Imgproc.cvtColor(rgbMat!!, hsvMat!!, Imgproc.COLOR_RGB2HSV)
                hsvMat!!.get(0, 0, hsvBytes)
            } catch (t: Throwable) {
                fallbackRgbaToHsv()
            }
        } else {
            fallbackRgbaToHsv()
        }
    }

    private fun fallbackRgbaToHsv() {
        val pixelCount = captureWidth * captureHeight
        val hsvTemp = FloatArray(3)
        var pIdx = 0
        var hIdx = 0
        val maxPixels = min(pixelCount, packedRgba.size / 4)
        for (i in 0 until maxPixels) {
            val r = packedRgba[pIdx].toInt() and 0xFF
            val g = packedRgba[pIdx + 1].toInt() and 0xFF
            val b = packedRgba[pIdx + 2].toInt() and 0xFF
            Color.RGBToHSV(r, g, b, hsvTemp)
            // OpenCV Hue scale is [0, 179]
            hsvBytes[hIdx] = ((hsvTemp[0] / 2.0f).toInt()).toByte()
            hsvBytes[hIdx + 1] = ((hsvTemp[1] * 255.0f).toInt()).toByte()
            hsvBytes[hIdx + 2] = ((hsvTemp[2] * 255.0f).toInt()).toByte()
            pIdx += 4
            hIdx += 3
        }
    }

    fun step(settings: BotSettings): Double? {
        if (!isCalibrated && settings.autoCalibrate) {
            autoCalibrate()
            if (!isCalibrated) return null
        } else if (!settings.autoCalibrate) {
            playerHueMin = settings.playerHueMin
            playerHueMax = settings.playerHueMax
            isCalibrated = true
        }

        // Apply morphological segmentation if OpenCV available
        if (isOpenCvLoaded && hsvMat != null && playerMask != null && enemyMask != null) {
            try {
                Core.inRange(
                    hsvMat!!,
                    Scalar(playerHueMin.toDouble(), PLAYER_S_MIN.toDouble(), PLAYER_V_MIN.toDouble()),
                    Scalar(playerHueMax.toDouble(), 255.0, 255.0),
                    playerMask!!
                )
                Core.inRange(
                    hsvMat!!,
                    Scalar(0.0, ENEMY_S_MIN.toDouble(), ENEMY_V_MIN.toDouble()),
                    Scalar(179.0, 255.0, 255.0),
                    enemyMask!!
                )
                Core.subtract(enemyMask!!, playerMask!!, enemyMask!!)
                if (morphKernel != null && enemyThickMask != null && enemyTrailMask != null) {
                    Imgproc.erode(enemyMask!!, enemyThickMask!!, morphKernel!!)
                    Core.subtract(enemyMask!!, enemyThickMask!!, enemyTrailMask!!)
                }
            } catch (t: Throwable) {
                Log.w(TAG, "OpenCV frame step failed, continuing", t)
            }
        }

        val head = findPlayerHead()
        if (head != null) {
            playerHead = head
        }

        val currentHead = playerHead ?: return null
        val chosenAngle = chooseBestDirection(currentHead, settings)

        if (settings.autoSkillsEnabled) {
            useSkillsIfNeeded(currentHead)
        }

        return chosenAngle
    }

    private fun autoCalibrate() {
        calibrationFrames++
        if (calibrationFrames < 10) return

        val hist = IntArray(180)
        val yStart = captureHeight / 4
        val yEnd = (captureHeight * 3) / 4
        val xStart = captureWidth / 4
        val xEnd = (captureWidth * 3) / 4

        for (y in yStart until yEnd step 6) {
            for (x in xStart until xEnd step 6) {
                val idx = (y * captureWidth + x) * 3
                if (idx + 2 >= hsvBytes.size) continue
                val h = hsvBytes[idx].toInt() and 0xFF
                val s = hsvBytes[idx + 1].toInt() and 0xFF
                val v = hsvBytes[idx + 2].toInt() and 0xFF
                if (s > 100 && v > 80) {
                    hist[h]++
                }
            }
        }

        var peakHue = 0
        var peakCount = 0
        for (h in 0 until 180) {
            if (hist[h] > peakCount) {
                peakCount = hist[h]
                peakHue = h
            }
        }

        if (peakCount > 25) {
            playerHueMin = (peakHue - 14).coerceAtLeast(0)
            playerHueMax = (peakHue + 14).coerceAtMost(179)
            isCalibrated = true
            Log.i(TAG, "Calibrated player hue range: $playerHueMin to $playerHueMax")
        }
    }

    private fun findPlayerHead(): Point? {
        val prev = playerHead
        var bestPoint: Point? = null
        var bestScore = -Double.MAX_VALUE

        val step = 6
        for (y in 10 until captureHeight - 10 step step) {
            for (x in 10 until captureWidth - 10 step step) {
                val idx = (y * captureWidth + x) * 3
                if (idx + 2 >= hsvBytes.size) continue
                val h = hsvBytes[idx].toInt() and 0xFF
                val s = hsvBytes[idx + 1].toInt() and 0xFF
                val v = hsvBytes[idx + 2].toInt() and 0xFF

                // Must match player hue with saturation
                if (h !in playerHueMin..playerHueMax || s < PLAYER_S_MIN || v < PLAYER_V_MIN) continue

                // Check neighborhood density
                var neighbors = 0
                for (dy in -8..8 step 4) {
                    for (dx in -8..8 step 4) {
                        if (dx == 0 && dy == 0) continue
                        val nx = x + dx
                        val ny = y + dy
                        if (nx < 0 || ny < 0 || nx >= captureWidth || ny >= captureHeight) continue
                        val nIdx = (ny * captureWidth + nx) * 3
                        if (nIdx + 2 >= hsvBytes.size) continue
                        val nh = hsvBytes[nIdx].toInt() and 0xFF
                        val ns = hsvBytes[nIdx + 1].toInt() and 0xFF
                        if (nh in playerHueMin..playerHueMax && ns >= PLAYER_S_MIN) {
                            neighbors++
                        }
                    }
                }
                // Head is leading edge with moderate neighboring pixels (trail or head), not deep interior
                if (neighbors > 20) continue

                var score = (25 - neighbors).toDouble()
                if (prev != null) {
                    val d = hypot(x - prev.x, y - prev.y)
                    if (d > 220) continue
                    score += (220 - d) * 0.6
                }
                if (score > bestScore) {
                    bestScore = score
                    bestPoint = Point(x.toDouble(), y.toDouble())
                }
            }
        }
        return bestPoint
    }

    private fun chooseBestDirection(head: Point, settings: BotSettings): Double {
        var hadDanger = false
        var bestScore = -Double.MAX_VALUE
        var bestAngle = lastDirection

        val rayLength = settings.playstyle.rayLength
        val cautionWeight = settings.playstyle.cautionWeight

        for (i in 0 until RAY_COUNT) {
            val angle = i * (2.0 * Math.PI / RAY_COUNT)
            val result = scoreRay(head, angle, rayLength, cautionWeight)
            if (result.score < -1000) continue
            if (result.score > bestScore) {
                bestScore = result.score
                bestAngle = angle
            }
            if (result.danger) hadDanger = true
        }

        if (hadDanger && !dangerDetected) {
            evasionsCount++
        }
        dangerDetected = hadDanger
        return bestAngle
    }

    private data class RayResult(val score: Double, val danger: Boolean)

    private fun scoreRay(
        head: Point,
        angle: Double,
        rayLength: Double,
        cautionWeight: Double
    ): RayResult {
        val step = rayLength / RAY_SAMPLES
        var score = 0.0
        var danger = false

        for (s in 1..RAY_SAMPLES) {
            val d = s * step
            val x = (head.x + cos(angle) * d).toInt()
            val y = (head.y + sin(angle) * d).toInt()

            if (x < WALL_PROXIMITY_PX || y < WALL_PROXIMITY_PX ||
                x >= captureWidth - WALL_PROXIMITY_PX || y >= captureHeight - WALL_PROXIMITY_PX
            ) {
                return RayResult(-Double.MAX_VALUE, true)
            }

            val idx = (y * captureWidth + x) * 3
            if (idx + 2 >= hsvBytes.size) return RayResult(-Double.MAX_VALUE, true)

            val h = hsvBytes[idx].toInt() and 0xFF
            val sv = hsvBytes[idx + 1].toInt() and 0xFF
            val vv = hsvBytes[idx + 2].toInt() and 0xFF

            // Game perimeter/arena wall is dark
            if (vv < WALL_V_MAX) {
                return RayResult(-Double.MAX_VALUE, true)
            }

            val isEnemy = sv > ENEMY_S_MIN && vv > ENEMY_V_MIN && (h < playerHueMin || h > playerHueMax)
            if (isEnemy) {
                danger = true
                score -= (220.0 * cautionWeight) / s.toDouble()
                if (d < 110) return RayResult(-Double.MAX_VALUE, true)
            }

            // Unclaimed white arena surface
            if (sv < 55 && vv > 140) {
                score += 3.5
            } else if (isEnemy) {
                // Attacking enemy trail
                score += 1.5
            } else {
                // Own safe territory
                score += 1.0
            }
        }

        // Corridor block checks
        val perp1 = angle + Math.PI / 2
        val perp2 = angle - Math.PI / 2
        val corridorBlocked1 = isCorridorBlocked(head, perp1)
        val corridorBlocked2 = isCorridorBlocked(head, perp2)
        if (corridorBlocked1 && corridorBlocked2) score -= 180.0 * cautionWeight
        else if (corridorBlocked1 || corridorBlocked2) score -= 60.0 * cautionWeight

        // Angle momentum: penalize abrupt 180 flips that collide with own active trail
        val angleDiff = abs(normalizeAngle(angle - lastDirection))
        if (angleDiff < Math.PI / 4) score += 25.0
        else if (angleDiff > Math.PI * 0.75) score -= 45.0

        return RayResult(score, danger)
    }

    private fun isCorridorBlocked(head: Point, angle: Double): Boolean {
        for (s in 1..5) {
            val d = s * (CORRIDOR_CHECK_PX / 5.0)
            val x = (head.x + cos(angle) * d).toInt()
            val y = (head.y + sin(angle) * d).toInt()
            if (x < 0 || y < 0 || x >= captureWidth || y >= captureHeight) return true
            val idx = (y * captureWidth + x) * 3
            if (idx + 2 >= hsvBytes.size) return true
            if ((hsvBytes[idx + 2].toInt() and 0xFF) < WALL_V_MAX) return true
        }
        return false
    }

    private fun useSkillsIfNeeded(head: Point) {
        val now = System.currentTimeMillis()
        val enemyNearby = isEnemyNearby(head, DANGER_RADIUS_PX)

        for (i in 0 until skillButtonCount) {
            if (now - lastSkillUsedAt[i] < SKILL_COOLDOWN_MS) continue

            val bx = skillButtonXs[i].toInt()
            val by = skillButtonYs[i].toInt()
            if (bx < 0 || bx >= captureWidth || by < 0 || by >= captureHeight) continue

            var sumV = 0
            var sumS = 0
            var count = 0
            for (dy in -12..12 step 3) {
                for (dx in -12..12 step 3) {
                    val x = (bx + dx).coerceIn(0, captureWidth - 1)
                    val y = (by + dy).coerceIn(0, captureHeight - 1)
                    val idx = (y * captureWidth + x) * 3
                    if (idx + 2 >= hsvBytes.size) continue
                    sumV += hsvBytes[idx + 2].toInt() and 0xFF
                    sumS += hsvBytes[idx + 1].toInt() and 0xFF
                    count++
                }
            }
            if (count == 0) continue
            val avgV = sumV / count
            val avgS = sumS / count

            val isReady = avgV > SKILL_READY_BRIGHTNESS && avgS > SKILL_READY_SATURATION

            if (isReady && (enemyNearby || dangerDetected)) {
                val xNorm = bx.toFloat() / captureWidth
                val yNorm = by.toFloat() / captureHeight
                BotCommandBus.requestTap(xNorm, yNorm) {
                    lastSkillUsedAt[i] = System.currentTimeMillis()
                    skillsUsedCount++
                    BotCommandBus.addLog("Triggered speed skill #$i for tactical evasion")
                }
                return
            }
        }
    }

    private fun isEnemyNearby(head: Point, radius: Int): Boolean {
        val x0 = max(0, head.x.toInt() - radius)
        val y0 = max(0, head.y.toInt() - radius)
        val x1 = min(captureWidth - 1, head.x.toInt() + radius)
        val y1 = min(captureHeight - 1, head.y.toInt() + radius)

        for (y in y0..y1 step 6) {
            for (x in x0..x1 step 6) {
                val idx = (y * captureWidth + x) * 3
                if (idx + 2 >= hsvBytes.size) continue
                val h = hsvBytes[idx].toInt() and 0xFF
                val sv = hsvBytes[idx + 1].toInt() and 0xFF
                val vv = hsvBytes[idx + 2].toInt() and 0xFF
                if (sv > ENEMY_S_MIN && vv > ENEMY_V_MIN && (h < playerHueMin || h > playerHueMax)) {
                    return true
                }
            }
        }
        return false
    }

    private fun normalizeAngle(a: Double): Double {
        var x = a % (2.0 * Math.PI)
        if (x > Math.PI) x -= 2.0 * Math.PI
        if (x < -Math.PI) x += 2.0 * Math.PI
        return x
    }

    fun release() {
        try { rgbaMat?.release() } catch (_: Throwable) {}
        try { rgbMat?.release() } catch (_: Throwable) {}
        try { hsvMat?.release() } catch (_: Throwable) {}
        try { playerMask?.release() } catch (_: Throwable) {}
        try { enemyMask?.release() } catch (_: Throwable) {}
        try { enemyThickMask?.release() } catch (_: Throwable) {}
        try { enemyTrailMask?.release() } catch (_: Throwable) {}
        try { morphKernel?.release() } catch (_: Throwable) {}
    }
}
