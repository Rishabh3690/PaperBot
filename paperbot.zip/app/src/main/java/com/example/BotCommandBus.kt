package com.example

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

object BotCommandBus {
    private const val TAG = "PaperBotBus"

    @Volatile
    private var accessibilityServiceRef: WeakReference<BotAccessibilityService>? = null

    @Volatile
    private var foregroundServiceRef: WeakReference<BotForegroundService>? = null

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _isAccessibilityConnected = MutableStateFlow(false)
    val isAccessibilityConnected: StateFlow<Boolean> = _isAccessibilityConnected.asStateFlow()

    private val _isOverlayShowing = MutableStateFlow(false)
    val isOverlayShowing: StateFlow<Boolean> = _isOverlayShowing.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _currentStatus = MutableStateFlow("IDLE")
    val currentStatus: StateFlow<String> = _currentStatus.asStateFlow()

    private val _fps = MutableStateFlow(0)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private val _frameCount = MutableStateFlow(0L)
    val frameCount: StateFlow<Long> = _frameCount.asStateFlow()

    private val _evasionsCount = MutableStateFlow(0)
    val evasionsCount: StateFlow<Int> = _evasionsCount.asStateFlow()

    private val _skillsUsedCount = MutableStateFlow(0)
    val skillsUsedCount: StateFlow<Int> = _skillsUsedCount.asStateFlow()

    private val _detectedPlayerPos = MutableStateFlow<Pair<Float, Float>?>(null)
    val detectedPlayerPos: StateFlow<Pair<Float, Float>?> = _detectedPlayerPos.asStateFlow()

    private val _activeAngle = MutableStateFlow(0.0)
    val activeAngle: StateFlow<Double> = _activeAngle.asStateFlow()

    private val _visionMode = MutableStateFlow("OpenCV 4.9.0 Engine")
    val visionMode: StateFlow<String> = _visionMode.asStateFlow()

    private val _settings = MutableStateFlow(BotSettings())
    val settings: StateFlow<BotSettings> = _settings.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(listOf("PaperBot initialized and ready."))
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    fun attachAccessibility(service: BotAccessibilityService) {
        accessibilityServiceRef = WeakReference(service)
        _isAccessibilityConnected.value = true
        addLog("Accessibility touch injector connected.")
    }

    fun detachAccessibility(service: BotAccessibilityService) {
        if (accessibilityServiceRef?.get() === service) {
            accessibilityServiceRef = null
            _isAccessibilityConnected.value = false
            addLog("Accessibility touch injector disconnected.")
        }
    }

    fun attachForeground(service: BotForegroundService) {
        foregroundServiceRef = WeakReference(service)
        _isServiceRunning.value = true
        addLog("Vision & projection engine activated.")
    }

    fun detachForeground(service: BotForegroundService) {
        if (foregroundServiceRef?.get() === service) {
            foregroundServiceRef = null
            _isServiceRunning.value = false
            _currentStatus.value = "STOPPED"
            addLog("Vision engine stopped.")
        }
    }

    fun setOverlayShowing(showing: Boolean) {
        _isOverlayShowing.value = showing
    }

    fun togglePause() {
        val next = !_isPaused.value
        _isPaused.value = next
        addLog(if (next) "Bot paused by user." else "Bot resumed.")
    }

    fun setPaused(paused: Boolean) {
        _isPaused.value = paused
    }

    fun updateStatus(status: String) {
        _currentStatus.value = status
    }

    fun updateTelemetry(
        curFps: Int,
        totalFrames: Long,
        playerPos: Pair<Float, Float>?,
        angle: Double,
        evasions: Int,
        skills: Int
    ) {
        _fps.value = curFps
        _frameCount.value = totalFrames
        _detectedPlayerPos.value = playerPos
        _activeAngle.value = angle
        _evasionsCount.value = evasions
        _skillsUsedCount.value = skills
    }

    fun setVisionMode(mode: String) {
        _visionMode.value = mode
    }

    fun updateSettings(newSettings: BotSettings) {
        _settings.value = newSettings
        addLog("Updated playstyle to ${newSettings.playstyle.title}")
    }

    fun addLog(msg: String) {
        Log.i(TAG, msg)
        val current = _logs.value.toMutableList()
        if (current.size > 40) current.removeAt(0)
        current.add("[${System.currentTimeMillis() % 100000}] $msg")
        _logs.value = current
    }

    fun requestSwipe(x0: Float, y0: Float, x1: Float, y1: Float, danger: Boolean): Boolean {
        if (_isPaused.value) return false
        val service = accessibilityServiceRef?.get() ?: return false
        val gapMs = if (danger) _settings.value.dangerSwipeGapMs else _settings.value.normalSwipeGapMs
        return service.requestSwipe(x0, y0, x1, y1, danger, gapMs)
    }

    fun requestTap(x: Float, y: Float, onDispatched: () -> Unit): Boolean {
        if (_isPaused.value) return false
        val service = accessibilityServiceRef?.get() ?: return false
        return service.requestTap(x, y, onDispatched)
    }

    fun stopServices(context: Context) {
        context.stopService(Intent(context, BotForegroundService::class.java))
        context.stopService(Intent(context, FloatingHudService::class.java))
        _isServiceRunning.value = false
        _isOverlayShowing.value = false
        _currentStatus.value = "IDLE"
        addLog("Stopped all bot services.")
    }
}
