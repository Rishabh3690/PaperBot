package com.example

enum class Playstyle(
    val title: String,
    val description: String,
    val rayLength: Double,
    val cautionWeight: Double
) {
    BALANCED("Balanced", "Smooth territory expansion with active danger avoidance", 500.0, 1.0),
    AGGRESSIVE("Trail Hunter", "Aggressively pursues enemy trails to eliminate rivals", 650.0, 0.6),
    SAFE("Defensive", "Maintains small tight loops close to safe territory", 380.0, 1.6),
    SPEEDRUN("Speed Conqueror", "Large territorial claims with maximum skill usage", 750.0, 0.8)
}

data class BotSettings(
    val playstyle: Playstyle = Playstyle.BALANCED,
    val autoSkillsEnabled: Boolean = true,
    val dangerSwipeGapMs: Long = 30L,
    val normalSwipeGapMs: Long = 130L,
    val targetFps: Int = 30,
    val playerHueMin: Int = 80,
    val playerHueMax: Int = 140,
    val autoCalibrate: Boolean = true,
    val showFloatingHud: Boolean = true
)
