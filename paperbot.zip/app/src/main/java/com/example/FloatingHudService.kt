package com.example

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class FloatingHudService : Service() {

    private var windowManager: WindowManager? = null
    private var floatView: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        // Root container
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val bg = GradientDrawable().apply {
                setColor(0xEE0B132B.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFF2B7FFF.toInt())
            }
            background = bg
        }

        // Header Row: Status Indicator, Title, Pause Toggle, Close
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val statusDot = View(this).apply {
            val dotBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF10B981.toInt())
                setSize(dp(10), dp(10))
            }
            background = dotBg
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply {
                marginEnd = dp(6)
            }
        }

        val titleText = TextView(this).apply {
            text = "PaperBot"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(10)
            }
        }

        val statusLabel = TextView(this).apply {
            text = "RUNNING"
            setTextColor(0xFF00F0FF.toInt())
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(10)
            }
        }

        val pauseBtn = Button(this).apply {
            text = "PAUSE"
            setTextColor(Color.WHITE)
            textSize = 10f
            val btnBg = GradientDrawable().apply {
                setColor(0xFF1F2937.toInt())
                cornerRadius = dp(8).toFloat()
            }
            background = btnBg
            setPadding(dp(8), dp(4), dp(8), dp(4))
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setOnClickListener {
                BotCommandBus.togglePause()
            }
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            setTextColor(0xFF94A3B8.toInt())
            textSize = 11f
            background = null
            setPadding(dp(6), dp(2), dp(6), dp(2))
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setOnClickListener {
                stopSelf()
            }
        }

        headerRow.addView(statusDot)
        headerRow.addView(titleText)
        headerRow.addView(statusLabel)
        headerRow.addView(pauseBtn)
        headerRow.addView(closeBtn)

        // Telemetry details row (FPS, Evasions)
        val infoRow = TextView(this).apply {
            text = "FPS: 0 | Evasions: 0"
            setTextColor(0xFF94A3B8.toInt())
            textSize = 10f
            setPadding(dp(2), dp(4), dp(2), dp(0))
        }

        rootLayout.addView(headerRow)
        rootLayout.addView(infoRow)

        // Touch listener for dragging floating window
        rootLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(rootLayout, params)
                        return true
                    }
                }
                return false
            }
        })

        floatView = rootLayout
        windowManager?.addView(floatView, params)
        BotCommandBus.setOverlayShowing(true)

        // Observe status & telemetry
        scope.launch {
            BotCommandBus.currentStatus.collect { status ->
                statusLabel.text = status
                val dotColor = when (status) {
                    "RUNNING", "HUNTING TERRITORY" -> 0xFF10B981.toInt()
                    "CALIBRATING HUE" -> 0xFFFFB703.toInt()
                    "EVADING DANGER" -> 0xFFFF3366.toInt()
                    "PAUSED" -> 0xFF94A3B8.toInt()
                    else -> 0xFF2B7FFF.toInt()
                }
                val dotBg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(dotColor)
                    setSize(dp(10), dp(10))
                }
                statusDot.background = dotBg
            }
        }

        scope.launch {
            BotCommandBus.isPaused.collect { paused ->
                pauseBtn.text = if (paused) "RESUME" else "PAUSE"
            }
        }

        scope.launch {
            BotCommandBus.fps.collect { fps ->
                val evasions = BotCommandBus.evasionsCount.value
                val skills = BotCommandBus.skillsUsedCount.value
                infoRow.text = "FPS: $fps | Dodges: $evasions | Skills: $skills"
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        floatView?.let {
            windowManager?.removeView(it)
            floatView = null
        }
        BotCommandBus.setOverlayShowing(false)
        super.onDestroy()
    }
}
